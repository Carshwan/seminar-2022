# Seminar 2022 : Kotlin Spring MVC + JPA 강좌

> instructor: 강지혁 @jhvictor4