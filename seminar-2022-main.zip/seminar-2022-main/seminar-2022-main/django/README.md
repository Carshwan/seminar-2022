# Seminar 2022 : Django 강좌

> instructor: 김찬욱 @narayo9